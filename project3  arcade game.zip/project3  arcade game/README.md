# Classic Arcade Game Clone Project

## Table of Contents

- [Instructions](#instructions)
- [Contributing](#contributing)

## Instructions
open the HTML on Chrome browser .
 The challenge is to avoid the bugs that travel on the road. If a bug is touched, the character is reset back at the beginning. Upon reaching the water, the user is also reset back to the beginning.
 To move the player you can use the keyboard arrows to move up and down , left and right .


## Contributing

some Helpful files\ ["http://udacity.github.io/frontend-nanodegree-styleguide/javascript.html"]

["https://matthewcranford.com/arcade-game-walkthrough-part-1-starter-code-breakdown/"]
I learn more about README file ["https://classroom.udacity.com/courses/ud777/lessons/5338568539/concepts/876fb9ad-54c9-457f-b41b-b2676a30806b"]
